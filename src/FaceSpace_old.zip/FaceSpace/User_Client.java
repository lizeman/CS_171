//package FaceSpace;//package Final_Project;

import java.util.ArrayList;


public class User_Client {

    private HashTableLinearProbe<String, User> HashUserList;

    public User_Client() {
        HashUserList = new HashTableLinearProbe<String, User>(8);
    }


    public void addUser(String name, String profile) {
        if (HashUserList.contains(name)) {
            System.out.println("The username already exist, please change to another one");
        }

        HashUserList.put(name, new User(name, profile, new ArrayList<User>()));
    }

    public User getUser(String name) {
        return HashUserList.get(name);
    }


    public void addFriend(String name1, String name2) {
        User tmp1 = HashUserList.get(name1);
        User tmp2 = HashUserList.get(name2);

        if (tmp1 != null && tmp2 != null) {
            tmp1.setFriendList(tmp2);
            tmp2.setFriendList(tmp1);
            return;
        }
        System.out.println("Not found existing user");

    }

    public void deleteFriend(String name1, String name2) {
        User tmp1 = HashUserList.get(name1);
        User tmp2 = HashUserList.get(name2);

        if (tmp1 != null && tmp2 != null) {
            if (tmp1.removeFriend(name2)) {
                tmp2.removeFriend(name1);
                return;
            }
            return;
        }
        System.out.println("Not available");

    }

    public void removeUser(String name) {
        HashUserList.delete(name);

    }

    public void ShowAllUser() {
        System.out.println(HashUserList);
    }

    public void FindShortestPath(String name1, String name2) {
        User tmp1 = HashUserList.get(name1);
        User tmp2 = HashUserList.get(name2);

        if (tmp1 == null || tmp2 == null) {
            System.out.println("Not available");
            return;
        }

        BFS bfs = new BFS(HashUserList, tmp1, tmp2);

    }


    public static void main(String args[]) {
        User_Client test = new User_Client();
        test.addUser("1", "12312313");
        test.addUser("1", "12312313");

        test.addUser("2", "12312313");
        test.addUser("3", "12312313");
        test.addUser("4", "12312313");
        test.addUser("5", "12312313");
        test.addUser("6", "12312313");


        test.addFriend("1", "6");
        test.addFriend("2", "5");
        test.addFriend("2", "4");
        test.addFriend("2", "3");



        System.out.println(test.getUser("1").getFriendList());
        System.out.println("******************************");
        System.out.println(test.getUser("2").getFriendList());
        System.out.println("******************************");
        System.out.println(test.getUser("5").getFriendList());
        System.out.println("******************************");

//        test.deleteFriend("1", "2");
//        test.deleteFriend("1", "5");


        System.out.println(test.getUser("1").getFriendList());
        System.out.println("******************************");
        System.out.println(test.getUser("2").getFriendList());
        System.out.println("******************************");


        test.FindShortestPath("1", "6");
//        test.deleteFriend("1", "3");
//
//
//        test.deleteFriend("1", "2");
//
//        System.out.println(test.getUser("1").getFriendList());
//        System.out.println("******************************");
//        System.out.println(test.getUser("2").getFriendList());
//        System.out.println("******************************");
//
//        test.ShowAllUser();
//        System.out.println("******************************");

    }

}