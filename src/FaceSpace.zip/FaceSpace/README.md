###How to compile and run this project


````
cd /FaceSpace/..
javac *.class
java FaceSpace.User_Client
````

